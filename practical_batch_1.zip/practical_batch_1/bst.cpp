#include <stdio.h>
#include <conio.h>
#include <process.h>
#include <stdlib.h>

struct node
{
    node *right;
    int info;
    node *left;
}*root;

node* create();
void insert(int);
int height(node *)
int count_leaf(node*);
void search(int);
int main()
{
    int ch,n,z;
    //clrscr();
    do
    {
	printf("\nEnter Choice:->\n");
	printf("\n1:Insert:->\n");
	printf("\n2:Leaf_Node Count:->\n");
	printf("\n3:Tree Height:->\n");
	printf("\n4:Exit:->\n");

	scanf("%d",&ch);
	switch(ch)
	{
	    case 1:
	    printf("\nEnter Insert Value:->\n");
	    scanf("%d",&n);
	    insert(n);
	    break;

	    case 2:
	    z=count_leaf(root);
	    printf("\nTotal Leaf_Node=%d\n",z);
	    break;
		
		case 3:
    	z = height(root);
    	printf("\nHeight of the Tree = %d\n", z);
    	break;

		case 4:
    	exit(1);
		break;
	}
    } while (ch!=4);
    //getch();
    return 0;
}

node* create()
{
    node *p;
    p=(node*)malloc(sizeof(node));
    return (p);
}

void insert(int x)
{
    node *p,*temp;
    p=create();
    p->left=NULL;
    p->info=x;
    p->right=NULL;
    if(root==NULL)
    {
		root=p;
		printf("\nNode Is Inserted...\n");
    }
    else
    {
		temp=root;
		while(temp!=NULL)
		{
	    	if(p->info < temp->info)
	    	{
				if(temp->left==NULL)
				{
		    		temp->left=p;
		    		printf("\nNode Is Inserted...\n");
		    		break;
				}
				else
				{
		    		temp=temp->left;
				}
	    	}
	    	else if(p->info > temp->info)
	    	{
				if(temp->right==NULL)
				{
		    		temp->right=p;
		    		printf("\nNode Is Inserted...\n");
		    		break;
				}
				else
				{
		    		temp=temp->right;
				}
	    	}
		}
    }
}

int count_leaf(node *p)
{
    if(p==NULL)
    {
		return(0);
    }
    else if(p->left==NULL&&p->right==NULL)
    {
		printf("\t%d",p->info);
		return(1);
    }
    else
    {
		return(count_leaf(p->left)+count_leaf(p->right));
    }
}

int height(node *p)
{
    if (p == NULL)
        return -1;  
    else
    {
        int left_height = height(p->left);
        int right_height = height(p->right);
        return (left_height > right_height ? left_height : right_height) + 1;
    }
}

