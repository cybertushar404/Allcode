/*
For evaluation of postfix expression we require:
1) Any postfix expression string. 2) One Stack to store operand.

Algorithm:
Step 1: Start
Step 2: Input any postfix expression string.
Step 3: Read character by character of postfix expression string
Step 4: If reading character is -
* Operand then push it into stack.
* Operator then-
    I) Perform pop operation two times on to the stack.
    II) Calculate the value by using popped operands and reading operator.
    III) Push the calculated value into stack.
Step 5: Repeat the step 3 and step 4 till to the end of postfix expression.
Step 6: Perform pop operation one time onto stack and display popped value which is 
 value of postfix expression. Step 7) Stop
e.g.- 1) Evaluate the postfix expression: 345*+
         Value of given postfix expression is 23
*/
#include <conio.h>
#include <stdio.h>
#include <math.h>
#define max 100
struct stack
{
    int item[max], top;
};
void create(struct stack *);
void push(struct stack *, int);
int pop(struct stack *);
void main()
{
    struct stack *p, q;
    p = &q; // initialization of pointer
    char post[50];
    int i = 0, oprnd1, oprnd2, val, z;
    create(p); // stack creates
    printf("\n Enter postfix expression: ");
    scanf("%s", &exp);
    while (post[i] != '\0')
    {
        if (post[i] == '+' || post[i] == '-' || post[i] == '/' || post[i] == '*' || post[i] == '$')
        {
            oprnd2 = pop(p);
            oprnd1 = pop(p);
            switch (post[i])
            {
            case '+':
                val = oprnd1 + oprnd2;
                push(p, val);
                break;
            case '-':
                val = oprnd1 - oprnd2;
                push(p, val);
                break;
            case '/':
                val = oprnd1 / oprnd2;
                push(p, val);
                break;
            case '*':
                val = oprnd1 * oprnd2;
                push(p, val);
                break;
            case '$':
                val = pow(oprnd1, oprnd2);
                push(p, val);
                break;
            }
        }
        else
        {
            push(p, post[i] - 48);
        }
        i++;
    }
    z = pop(p);
    printf("\n Value of Postfix expression=%d", z);
}
void create(struct stack *p)
{
    p->top = -1;
}

void push(struct stack *p, int x)
{
    if (p->top == max - 1)
    {
        printf("Stack Overflow...\n");
    }
    else
    {
        p->top++;
        p->item[p->top] = x;
    }
}

int pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Underflow...\n");
        return '\0'; // Return a null character in case of underflow
    }
    else
    {
        return p->item[p->top--];
    }
}