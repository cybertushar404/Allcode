#include <stdio.h>
#include <stdlib.h>

struct node {
    int info;
    struct node *next;  // Use 'struct node' for the next pointer.
} *list = NULL;

struct node* create();
void ins_beg(int);
void ins_end(int);
void ins_bet(int, int);
int rem_beg();
int rem_end();
int rem_bet(int);
void display();
void search(int);
void count();
void reverse();

int main() {
    int ch, n, af, z;

    do {
        printf("\nEnter your choice:\n");
        printf("1: Insert at Beginning\n2: Insert at End\n3: Insert After a Node\n4: Remove from Beginning\n");
        printf("5: Remove from End\n6: Remove After a Node\n7: Display\n8: Search\n9: Count\n10: Reverse\n11: Exit\n");
        scanf("%d", &ch);

        switch(ch) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &n);
                ins_beg(n);
                break;
            case 2:
                printf("Enter value to insert: ");
                scanf("%d", &n);
                ins_end(n);
                break;
            case 3:
                printf("After which node? ");
                scanf("%d", &af);
                printf("Enter value to insert: ");
                scanf("%d", &n);
                ins_bet(af, n);
                break;
            case 4:
                z = rem_beg();
                if (z != -1) printf("Removed value = %d\n", z);
                break;
            case 5:
                z = rem_end();
                if (z != -1) printf("Removed value = %d\n", z);
                break;
            case 6:
                printf("After which node? ");
                scanf("%d", &af);
                z = rem_bet(af);
                if (z != -1) printf("Removed value = %d\n", z);
                break;
            case 7:
                display();
                break;
            case 8:
                printf("Enter Element To Be Searched: ");
                scanf("%d",&n);
                search(n);
                break;
            case 9:
                count();
                break;
            case 10:
                reverse();
                break;
            case 11:
                printf("Exiting...\n");
                exit(0);
                break;
            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }
    } while(ch != 11);

    return 0;
}

struct node* create() {
    struct node *z = (struct node*) malloc(sizeof(struct node));  // Allocate memory for 'struct node'
    if (!z) {
        printf("Memory allocation failed.\n");
        exit(1);
    }
    return z;
}

void ins_beg(int x) {
    struct node *p = create();
    p->info = x;
    p->next = list;
    list = p;
    printf("Node is inserted at the beginning...\n");
}

void ins_end(int x) {
    struct node *p = list, *q;

    if (p == NULL) {
        ins_beg(x);  // Insert at beginning if list is empty
        return;
    }

    while (p->next != NULL) {
        p = p->next;
    }
    q = create();
    q->info = x;
    q->next = NULL;
    p->next = q;
    printf("Node is inserted at the end...\n");
}

void ins_bet(int after, int x) {
    struct node *p = list, *q;

    while (p != NULL) {
        if (p->info == after) {
            q = create();
            q->info = x;
            q->next = p->next;
            p->next = q;
            printf("Node is inserted after %d...\n", after);
            return;
        }
        p = p->next;
    }
    printf("Node with value %d not found.\n", after);
}

int rem_beg() {
    if (list == NULL) {
        printf("List is empty.\n");
        return -1;
    }

    struct node *p = list;
    int z = p->info;
    list = p->next;
    free(p);
    return z;
}

int rem_end() {
    struct node *p = list, *temp;

    if (p == NULL) {
        printf("List is empty.\n");
        return -1;
    }

    if (p->next == NULL) {
        return rem_beg();  // Remove the only node in the list
    }

    while (p->next->next != NULL) {
        p = p->next;
    }

    temp = p->next;
    int z = temp->info;
    p->next = NULL;
    free(temp);
    return z;
}

int rem_bet(int after) {
    struct node *p = list, *temp;

    while (p != NULL && p->next != NULL) {
        if (p->info == after) {
            temp = p->next;
            int z = temp->info;
            p->next = temp->next;
            free(temp);
            return z;
        }
        p = p->next;
    }
    printf("Node with value %d not found or has no following node.\n", after);
    return -1;
}

void display() {
    struct node *p = list;

    if (p == NULL) {
        printf("List is empty.\n");
        return;
    }

    while (p != NULL) {
        printf("%d -> ", p->info);
        p = p->next;
    }
    printf("NULL\n");
}

void search(int n) {
    struct node *p = list;
    while (p != NULL) {
        if (p->info == n) {
            printf("Node with value %d is found.\n", n);
            return;
        }
        p = p->next;
    }
    printf("Node with value %d not found.\n", n);
}

void count() {
    int cnt = 0;
    struct node *p = list;
    while (p != NULL) {
        cnt++;
        p = p->next;
    }
    printf("Total number of nodes is: %d\n", cnt);
}

void reverse() {
    struct node *t1 = list, *t2, *t3 = NULL;
    while (t1 != NULL) {
        t2 = t1->next;
        t1->next = t3;
        t3 = t1;
        t1 = t2;
    }
    list = t3;
    printf("Linked list is reversed.\n");
}
