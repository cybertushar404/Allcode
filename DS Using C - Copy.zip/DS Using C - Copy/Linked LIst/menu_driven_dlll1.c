#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *next; // Use 'struct node' for the next pointer.
    struct node *prev; // Use 'struct node' for the prev pointer.
} *list;

struct node *create();
void ins_beg(int);
void ins_end(int);
void ins_bet(int, int);
int rem_beg();
int rem_end();
int rem_bet(int);
void display();
void search(int);
void count();
void reverse();

int main()
{
    int ch, n, af, z;

    do
    {
        printf("\nEnter your choice:\n");
        printf("1: Insert at Beginning\n2: Insert at End\n3: Insert After a Node\n4: Remove from Beginning\n5: Remove from End\n6: Remove After a Node\n7: Display\n8: Search\n9: Count\n10: Reverse Linked List\n11: Exit\n");
        scanf("%d", &ch);

        switch (ch)
        {
        case 1:
            printf("Enter value to insert: ");
            scanf("%d", &n);
            ins_beg(n);
            break;
        case 2:
            printf("Enter value to insert: ");
            scanf("%d", &n);
            ins_end(n);
            break;
        case 3:
            printf("After which node? ");
            scanf("%d", &af);
            printf("Enter value to insert: ");
            scanf("%d", &n);
            ins_bet(af, n);
            break;
        case 4:
            z = rem_beg();
            printf("Removed value = %d\n", z);
            break;
        case 5:
            z = rem_end();
            printf("Removed value = %d\n", z);
            break;
        case 6:
            printf("After which node? ");
            scanf("%d", &af);
            z = rem_bet(af);
            printf("Removed value = %d\n", z);
            break;
        case 7:
            display();
            break;
        case 8:
            printf("Enter Element To Be Searched: ");
            scanf("%d", &n);
            search(n);
            break;
        case 9:
            count();
            break;
        case 10:
            reverse();
            break;
        case 11:
            exit(1);
            break;
        }
    } while (ch != 11);

    return 0;
}

struct node *create()
{
    struct node *z;
    z = (struct node *)malloc(sizeof(struct node)); // Allocate memory for 'struct node'
    return z;
}

void ins_beg(int x)
{
    struct node *p = list, *q;

    if (p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        p->prev = NULL;
        list = p;
    }
    else
    {
        q = create();
        q->info = x;
        q->next = p;
        q->prev = NULL;
        p->prev = q;
        list = q;
    }
    printf("Node is inserted at the beginning...\n");
}

void ins_end(int x)
{
    struct node *p = list, *q;

    if (p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        p->prev = NULL;
        list = p;
    }
    else
    {
        while (p->next != NULL)
        {
            p = p->next;
        }
        q = create();
        q->prev = p;
        q->info = x;
        q->next = NULL;
        p->next = q;
    }
    printf("Node is inserted at the end...\n");
}

void ins_bet(int after, int x)
{
    struct node *p = list, *q;

    if (p == NULL || p->prev == NULL && p->next == NULL)
    {
        printf("Insertion not possible, list is empty.\n");
        return;
    }

    while (p != NULL)
    {
        if (p->info == after)
        {
            q = create();
            q->prev = p;
            q->info = x;
            q->next = p->next;
            p->next->next = q;
            p->next = q;
            printf("Node is inserted after %d...\n", after);
            return;
        }
        p = p->next;
    }
    printf("Node with value %d not found.\n", after);
}

int rem_beg()
{
    int z;
    struct node *p = list;

    if (p == NULL)
    {
        printf("List is empty.\n");
        return -1;
    }
    else if (p->prev == NULL && p->next == NULL)
    {
        z = p->info;
        free(p);
        list = NULL;

        return z;
    }
    else
    {
        z = p->info;
        p->next->prev = NULL;
        list = p->next;
        free(p);
        return z;
    }
}

int rem_end()
{
    int z;
    struct node *p = list, *temp;

    if (p == NULL)
    {
        printf("List is empty.\n");
        return -1;
    }

    else if (p->prev == NULL && p->next == NULL)
    {
        z = p->info;
        free(p);
        list = NULL;
        return z;
    }
    else
    {
        while (p->next->next != NULL)
        {
            p = p->next;
        }

        temp = p->next;
        z = temp->info;
        p->next = NULL;
        free(temp);

        return z;
    }
}

int rem_bet(int after)
{
    int z;
    struct node *p = list, *temp;

    if (p == NULL)
    {
        printf("List is empty.\n");
        return -1;
    }
    else if ((p->prev == NULL && p->next == NULL) || (p->prev == NULL && p->next->next == NULL))
    {
        printf("\nRemove Beetween Not Possible...");
    }
    else
    {
        while (p->next != NULL)
        {
            if (p->info == after)
            {
                temp = p->next;
                z = temp->info;
                temp->next->prev = p;
                p->next = temp->next;
                free(temp);
                return z;
            }
            p = p->next;
        }
        printf("Node with value %d not found or has no following node.\n", after);
        return -1;
    }
}

void display()
{
    struct node *p = list;

    if (p == NULL)
    {
        printf("List is empty.\n");
        return;
    }

    while (p != NULL)
    {
        printf("%d -> ", p->info);
        p = p->next;
    }
    printf("NULL\n");
}

void search(int n)
{
    int t = 0;
    struct node *p;
    p = list;
    while (p != NULL)
    {
        if (p->info == n)
        {
            t = 1;
            break;
        }
        p = p->next;
    }
    if (t == 1)
    {
        printf("Node Is Found...");
    }
    else
    {
        printf("Node Not Found...");
    }
}

void count()
{
    int cnt = 0;
    struct node *p;
    p = list;
    while (p != NULL)
    {
        cnt++;
        p = p->next;
    }
    if (cnt == 1)
    {
        printf("Total Number Of Node Is: %d\n", cnt);
    }
    else
    {
        printf("Total Number Of Nodes Are: %d\n", cnt);
    }
}

void reverse()
{
    struct node *t1, *t2, *t3 = NULL;
    t1 = list;
    while (t1 != NULL)
    {
        t2 = t3->prev;
        t1->next = t3;
        t1->prev = t2;
        t3 = t1;
        t1 = t2;
    }
    list = t3;
    printf("\nLinked List Is Reversed...");
}