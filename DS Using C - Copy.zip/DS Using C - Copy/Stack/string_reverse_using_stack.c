#include <stdio.h>
#define max 50
struct stack
{
    int item[max];
    int top;
};
void create(struct stack *p);
void push(struct stack *p, int);
int pop(struct stack *p);
void main()
{
    int x, i = 0, j = 0;
    struct stack *p, s;
    p = &s;
    char str[50], rev[50];
    create(p);
    printf("\nEnter Any String: ");
    scanf("%s", &str);
    while (str[i] != '\0')
    {
        push(p, str[i]);
        i++;
    }
    while (p->top != -1)
    {
        rev[j] = pop(p);
        j++;
    }
    rev[j] = '\0';
    printf("\nReversed String Is =%s", rev);
}

void create(struct stack *p)
{
    p->top = -1;
}
void push(struct stack *p, int x)
{
    if (p->top == max - 1)
    {
        printf("\nStack Overflow...");
    }
    else
    {
        ++p->top;
        p->item[p->top] = x;
    }
}
int pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Underflow");
        return 0;
    }
    else
    {
        return (p->item[p->top--]);
    }
}