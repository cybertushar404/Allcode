#include <stdio.h>
int find_min(int a[])
{
    int t = a[0];
    for (int i = 1; i < 10; i++)
    {
        if (a[i] < t)
        {
            t = a[i];
        }
    }
    return t;
    // printf("\nMin Number From Array Is: %d", t);
}
int find_max(int a[])
{
    int t = a[0];
    for (int i = 1; i < 10; i++)
    {
        if (a[i] > t)
        {
            t = a[i];
        }
    }
    return t;
    // printf("\nMax Number From Array Is: %d", t);
}
void main()
{
    int min, max, a[10] = {0};
    printf("Enter Any 10 Numbers: ");
    for (int i = 0; i <= 9; i++)
    {
        scanf("%d", &a[i]);
    }
    min = find_min(a);
    max = find_max(a);
    printf("\nMin Number From Array Is: %d", min);
    printf("\nMax Number From Array Is: %d", max);
}