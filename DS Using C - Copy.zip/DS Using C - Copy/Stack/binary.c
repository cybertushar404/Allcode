#include <stdio.h>
#define max 32
struct stack
{
    int item[max];
    int top;
} s;
void create(struct stack *);
void push(struct stack *, int x);
int pop(struct stack *);
int main()
{
    // struct stack *p;
    struct stack *p = &s;
    int n, y, temp, rem;
    create(p);
    printf("Enter Integer Number: ");
    scanf("%d", &n);
    temp = n;
    while (n > 0)
    {
        rem = n % 2;
        push(p, rem);
        n = n / 2;
    }
    printf("Binary Representation Of %d is: ", temp);
    while(p->top!=-1)
    {
        y = pop(p);
        printf("%d",y);
    }
    return 0;
}
void create(struct stack *p)
{
    p->top = -1;
}
void push(struct stack *p, int x)
{
    if (p->top == max - 1)
    {
        printf("\nStack Overflow..");
    }
    else
    {
        p->item[++p->top] = x;
    }
}
int pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("\nStack Underflow");
        return (0);
    }
    else
    {
        return (p->item[p->top--]);
    }
}