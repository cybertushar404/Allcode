/*#include <stdio.h>
void rev(int a[])
{
    int i, j, b[10];
    for (i = '\0', j = 0; i >= 0 && j < 10; i-- && j++)
    {
        a[i]=b[j];
    }
    //return b;
    for (int i=0;i<10;i++)
    {
        printf("%d",b[i]);
    }
}
void main()
{
    int a[10], z;
    printf("Enter The Elements: ");
    for (int i = 0; i < 10; i++)
    {
        scanf("%d", &a[i]);
    }
    rev(a);
}*/
#include <stdio.h>

/*void rev(int a[], int b[], int n) {
    int i;
    for (i = 0; i < n; i++) {
        b[n - i - 1] = a[i];
    }
}

/*int main() {
    int a[10], b[10];
    printf("Enter The Elements: ");
    for (int i = 0; i < 10; i++) {
        scanf("%d", &a[i]);
    }
    rev(a, b, 10);
    printf("Original array: ");
    for (int i = 0; i < 10; i++) {
        printf("%d ", a[i]);
    }
    printf("\nReversed array: ");
    for (int i = 0; i < 10; i++) {
        printf("%d ", b[i]);
    }
    return 0;
}

int main() {
    int a[10], b[10];
    printf("Enter The Elements: ");
    for (int i = 0; i < 10; i++) {
        scanf("%d", &a[i]);
    }
   // rev(a, b, 10);
    printf("Original array: ");
    for (int i = 0; i < 10; i++) {
        printf("%d ", a[i]);
    }
}

void main()
{
    int a[10];
    printf("Enter Any 10 NUmbers: ");
    // int a[]={1,2,3,4,5,6,7,8,9,0};
    for (int i = 0; i < 10; i++)
    {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < 10; i++)
    {
        printf("%d  ", a[i]);
    }
}*/