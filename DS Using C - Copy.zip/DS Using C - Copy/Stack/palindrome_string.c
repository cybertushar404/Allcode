#include <stdio.h>
#define max 50
struct stack
{
    int item[max];
    int top;
} s;
void create(struct stack *);
void push(struct stack *, char x);
char pop(struct stack *);
int main()
{
    struct stack *p = &s;
    int i=0, j=0,k=0;
    char ch, in[50], out[50];
    create(p);
    printf("Enter A String: ");
    scanf("%s", &in);
    while (in[i] != '\0')
    {
        push(p, in[i]);
        i++;
    }
    while (p->top != -1)
    {
        out[j] = pop(p);
        j++;
    }
    out[j] = '\0';
    /*while(in[i] != '\0' && out[j] != '\0')
    {
        if(in[i]==out[j])
        {
            k=1;
        }
        i++,j++;
    }
    if(k==1)
    {
        printf("Entered String Is Palindrome");
    }
    else 
    {
        printf("Entered String Is Not Palindrome");
    }
    return 0;*/
    for (i=0,j=0;in[i] != '\0' && out[j] != '\0';i++,j++)
    {
        if (in[i] != out[j])
        {
            printf("Entered String Is Not Palindrome...");
            return 0;
        }
    }
        printf("Entered String Is Palindrome...");
        return 0;
}
void create(struct stack *p)
{
    p->top = -1;
}
void push(struct stack *p, char x)
{
    if (p->top == max - 1)
    {
        printf("Stack Overflow...");
    }
    else
    {
        p->item[++p->top] = x;
    }
}
char pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Underflow...");
        return 0;
    }
    else
    {
        return p->item[p->top--];
    }
}