#include<stdio.h>
#include<conio.h>
void reverse()
{
    
}