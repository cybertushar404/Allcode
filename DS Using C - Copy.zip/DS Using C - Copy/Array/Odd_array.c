#include <stdio.h>
void main()
{
    int cnt, a[10];
    printf("Enter 10 Numbers:");
    for (int i = 0; i <= 9; i++)
    {
        scanf("%d", a[i]);
    }
    for (int i = 0; i <= 9; i++)
    {
        if (a[i] % 2 == 1)
        {
            printf("%d", a[i]);
            cnt++;
        }
    }
    printf("\nTotal Odd Numbers Are: %d.", cnt);
}