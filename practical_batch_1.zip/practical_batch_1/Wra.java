import java.util.*;
public class Wra {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        int x;
        System.out.println("Enter Any Integer: ");
        x=sc.nextInt();
        Integer intObj = x;

        Double doubleObj = intObj.doubleValue(); 
        System.out.println("Integer to Double: " + doubleObj);

        Long longObj = doubleObj.longValue();
        System.out.println("Double to Long: " + longObj);

        Float floatObj = longObj.floatValue();
        System.out.println("Long to Float: " + floatObj);

        Byte byteObj = (byte) floatObj.floatValue();
        System.out.println("Float to Byte: " + byteObj);
    }
}
