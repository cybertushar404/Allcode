#include <stdio.h>
void main()
{
    int cnt, a[10];
    printf("Enter Any 10 Numbers:");
    for (int i = 0; i <= 9; i++)
    {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i <= 9; i++)
    {
        if (a[i] % 2 == 0)
        {
            printf("%d ", a[i]);
            cnt++;
        }
        printf("\nTotal Even Numbers In Array: %d.", cnt);
    }
}