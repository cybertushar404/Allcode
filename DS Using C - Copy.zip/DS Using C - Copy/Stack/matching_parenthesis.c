/*
To check expression is balanced (Valid) or Not, we require following Things:
1) An expression which is parenthesized.
2) Stack to store opening parenthesis.

Algorithm:
Step 1: Start
Step 2: Input an infix expression which is parenthesized.
Step 3: Read character by character of an infix expression
Step 4: If reading character is:
        * Opening parenthesis then push it into stack.
        * closing parenthesis then perform pop operation one time onto stack and compare popped opening parenthesis with reading closing parenthesis,
        If popped opening parenthesis is not matches with reading closing parenthesis 
        then display “Expression is Invalid” and goto Step 7.
        Else if popped opening parenthesis is matches with reading closing parenthesis then it is OK, read next character.
Step 5: Repeat the step 3 and 4 till to the end of input expression.
Step 6: After reading entire expression, check stack is empty or not.
If Stack is not empty then display “Expression is Invalid”
Else display “Expression is Valid”. 
Step 7: Stop
*/
#include <stdio.h>
#define max 50
struct stack
{
    int item[max];
    int top;
};
void create(struct stack *);
int pop(struct stack *);
void push(struct stack *, int);

void main()
{
    int i = 0, temp = 0;
    char in[50], ch;
    struct stack *p, q;
    p = &q;
    create(p);
    printf("Enter Infix Expression: ");
    scanf("%s", &in);
    while (in[i] != '\0')
    {
        if (in[i] == '(' || in[i] == '[' || in[i] == '{')
        {
            push(p, in[i]);
        }
        else if (in[i] == ')' || in[i] == ']' || in[i] == '}')
        {
            ch = pop(p);
            if ((ch == '(') != (in[i] == ')') || (ch == '[') != (in[i] == ']') || (ch == '{') != (in[i] == '}'))
            {
                temp = 1;
                break;
            }
        }
        i++;
    }
    if (p->top != -1 || temp == 1)
    {
        printf("Entered Expression Is Invalid...");
    }
    else
    {
        printf("Entered Expression Is Valid...");
    }
}

void create(struct stack *p)
{
    p->top = -1;
}

void push(struct stack *p, int x)
{
    if (p->top == max - 1)
    {
        printf("Stack Overflow...\n");
    }
    else
    {
        p->top++;
        p->item[p->top] = x;
    }
}

int pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Underflow...\n");
        return '\0'; // Return a null character in case of underflow
    }
    else
    {
        return p->item[p->top--];
    }
}
/*
#include <stdbool.h>
#include <stdlib.h>

#define MAX_SIZE 10000

typedef struct {
    char items[MAX_SIZE];
    int top;
} Stack;

// Function to initialize the stack
void initStack(Stack *s) {
    s->top = -1;
}

// Function to check if the stack is empty
bool isEmpty(Stack *s) {
    return s->top == -1;
}

// Function to push an item onto the stack
bool push(Stack *s, char item) {
    if (s->top < MAX_SIZE - 1) {
        s->items[++s->top] = item;
        return true;
    }
    return false;
}

// Function to pop an item from the stack
char pop(Stack *s) {
    if (!isEmpty(s)) {
        return s->items[s->top--];
    }
    return '\0'; // Return null character if stack is empty
}

// LeetCode function to validate parentheses
bool isValid(char *s) {
    Stack stack;
    initStack(&stack);

    for (int i = 0; s[i] != '\0'; i++) {
        char current = s[i];

        // Push opening brackets onto the stack
        if (current == '(' || current == '{' || current == '[') {
            push(&stack, current);
        }
        // Check for matching opening brackets with closing brackets
        else if (current == ')' || current == '}' || current == ']') {
            if (isEmpty(&stack)) {
                return false; // No matching opening bracket
            }
            char top = pop(&stack);
            if ((current == ')' && top != '(') ||
                (current == '}' && top != '{') ||
                (current == ']' && top != '[')) {
                return false; // Mismatched brackets
            }
        }
    }

    // Valid if stack is empty at the end
    return isEmpty(&stack);
}
*/