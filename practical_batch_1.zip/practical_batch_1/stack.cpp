 /*

***STACK***

Definition: “Stack is the linear data structure which is an ordered collection of elements or 
items into which elements or items are inserted (push) and removed (pop) from only one end
that end is called top of Stack.”
The Stack operates in LIFO (Last In First Out) manner i.e. the element which is lastly 
inserted in stack is the element to come out first from stack. Because stack has only one end 
to insert and remove element.
e.g.- 1) Stack of CD plates-
In Stack of CD plate only topmost CD can be taken out and any new CD can be put at the 
top.
2) Stack of boxes.
*/
#include <stdio.h>
#include <process.h>
#define max 5
struct stack
{
    int item[max], top;
} s;
void create(struct stack *);
void isempty(struct stack *);
void isfull(struct stack *);
void push(struct stack *, int);
int pop(struct stack *);
void display(struct stack *);
int main()
{
    struct stack *p;
    p = &s;
    int x, y, z;
    do
    {
        printf("\nEnter Your Choice: \n");
        printf("\n1: Create\n2: Isempty\n3: Isfull\n4: Push\n5: Pop\n6: Display\n7: Exit\n");
        scanf("%d", &y);
        printf("Your Choice Is: %d\n", y);
        switch (y)
        {
        case 1:
            create(p);
            break;
        case 2:
            isempty(p);
            break;
        case 3:
            isfull(p);
            break;
        case 4:
            printf("Enter Element To Push: ");
            scanf("%d", &x);
            push(p, x);
            printf("Element %d Is Pushed In Stack\n", x);
            break;
        case 5:
            z = pop(p);
            if (z != 0)
            {
                printf("Element %d Is Popped Out Of The Stack: \n", z);
            }
            else
            {
                printf("Stack Doesn't Contains Any Element To Be Popped\n");
            }
            break;
        case 6:
            display(p);
            break;
        default:
            printf("Invalid Choice...\nChoose Correct Choice :(");
        }
    } while (y != 7);
    printf("Exit Successful...");
    return 0;
}
void create(struct stack *p)
{
    p->top = -1;
    printf("Stack Is Created\n");
}
void isempty(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Is Empty\n");
    }
    else
    {
        printf("Stack Is Not Empty\n");
    }
}
void isfull(struct stack *p)
{
    if (p->top == max - 1)
    {
        printf("Stack Is Full\n");
    }
    else
    {
        printf("Stack Is Not Full\n");
    }
}
void push(struct stack *p, int x)
{
    if (p->top == max - 1)
    {
        printf("Stack Overflow\n");
    }
    else
        ++p->top;
    p->item[p->top] = x;
    printf("%d Is Pushed In Stack...\n");
}
int pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Underflow...\n");
        return 0;
    }
    else
    {
        return (p->item[p->top--]);
        //return 1;
    }
    
}
void display(struct stack *p)
{
    printf("The Stack Contains Following Elements / Members: ");
    for (int i = p->top; i >= 0; i--)
    {
        printf("%d", p->item[i]);
        if (i > 0)
        {
            printf(", ");
        }
        else
        {
            printf(". ");
        }
    }
}
