/*
To convert Infix Expression into Postfix Expression we require following things:
Requirements:
1) Infix expression string which is parenthesized.
2) Stack to store opening parenthesis and operator.
3) Postfix expression string to store result.
Algorithm:
Step 1: Start
Step 2: Input infix expression string which is parenthesized.
Step 3: Read character by character of the infix expression string.
Step 4: * If Reading character is Opening parenthesis or operator then push that character 
        into stack.
        * If Reading character is Operand then add it into postfix expression string.
        * If Reading character is closing parenthesis then repeatedly pop the stack and add 
        the popped character into postfix expression string if it is not parenthesis, until 
        the corresponding opening parenthesis is encountered.
Step 5: Repeat the Step 3 and Step 4 till to the end of infix expression string.
Step 6: After reading entire infix expression string,
        Check stack is empty or not. If Stack is Not empty then perform pop operation repeatedly 
        until stack becomes empty and add popped character into postfix expression string if it not 
        parenthesis.
Step 7: Display postfix expression string.
Step 8: Stop
e.g. - Infix Expression: ( ( X + Y ) * Z )
Postfix expression is: XY+Z*
*/
#include <stdio.h>
#include <string.h>
#define max 50

struct stack
{
    char item[max];
    int top;
} s;

void create(struct stack *p);
void push(struct stack *p, int x);
int pop(struct stack *p);

int main()
{
    char in[50], post[50], ch;
    int i = 0, j = 0, x;
    struct stack *p = &s;

    create(&s);

    printf("\nEnter Infix Exp: ");
    scanf("%s", in);

    // Process the input expression
    while (in[i] != '\0')
    {
        if (in[i] == '(')
        {
            push(p, in[i]);
        }
        else if (in[i] == '+' || in[i] == '-' || in[i] == '*' || in[i] == '/' || in[i] == '^' || in[i] == '$')
        {
            push(p, in[i]);
        }
        else if (in[i] == ')')
        {
            while (p->item[p->top] != '(')
            {
                ch = pop(p);
                if (ch != ')')
                {
                    post[j] = ch;
                    j++;
                }
            }
            pop(p);
        }
        else
        {
            post[j] = in[i];
            j++;
        }
        i++;
    }
    if (p->top != -1)
    {
        while (p->top != -1)
        {
            ch = pop(p);
            if (ch != '(')
            {
                post[j] = ch;
                j++;
            }
        }
    }
    post[j] = '\0';
    printf("\nPostfix Exp: %s\n", post);
    return 0;
}

void create(struct stack *p)
{
    p->top = -1;
}

void push(struct stack *p, int x)
{
    if (p->top == max - 1)
    {
        printf("Stack Overflow...\n");
    }
    else
    {
        p->top++;
        p->item[p->top] = x;
    }
}

int pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Underflow...\n");
        return '\0'; // Return a null character in case of underflow
    }
    else
    {
        return p->item[p->top--];
    }
}