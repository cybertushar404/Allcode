#include <stdio.h>
#define max 10
struct stack
{
    int item[max];
    int top;
};
void create(struct stack *p)
{
    p->top = -1;
}
void push(struct stack *p, int x)
{
    if (p->top == max - 1)
    {
        printf("Stack Overflows...");
    }
    else
    {
        ++p->top;
        p->item[p->top] = x;
    }
}
int pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Underflows");
    }
    else
    {
        return (p->item[p->top--]);
    }
}
void main()
{
    int i, a[10];
    struct stack *p, s;
    p = &s;
    printf("Enter 10 Elements:");
    for (i = 0; i < 10; i++)
    {
        scanf("%d", &a[i]);
    }
    while (a[i] != '\0')
    {
        push(p, a[i]);
    }
    while (p->top != -1)
    {
        a[i]=pop(p);
        i++;
    }
    for(int i=0;i<11;i++){
        printf("\t%d",a[i]);
    }
}


#include <stdio.h>
#define max 50
struct stack
{
    int item[max];
    int top;
};
void create(struct stack *p);
void push(struct stack *p, int);
int pop(struct stack *p);
void main()
{
    int x, i = 0, j = 0;
    struct stack *p, s;
    p = &s;
    int a[10],r[10];
    create(p);
    printf("\nEnter Any 10 Elements: ");
    for (int i = 0; i < 10; i++)
    {
        scanf("%d", &a[i]);
    }
    while (a[i] != '\0')
    {
        push(p, a[i]);
        i++;
    }
    while (p->top != -1)
    {
        r[j] = pop(p);
        j++;
    }
    r[j] = '\0';
    for (int i = 0; i < 10; i++)
    {
        printf("\nReversed Array Is =%d",r[i]);
    }
}

void create(struct stack *p)
{
    p->top = -1;
}
void push(struct stack *p, int x)
{
    if (p->top == max - 1)
    {
        printf("\nStack Overflow...");
    }
    else
    {
        ++p->top;
        p->item[p->top] = x;
    }
}
int pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Underflow");
        return 0;
    }
    else
    {
        return (p->item[p->top--]);
    }
}

#include <stdio.h>
void main ()
{
    int a[5];
    for(int i=0;i<5;i++){
        scanf("%d",&a[i]);
    }
    
    for(int i=0;i<5;i++){
        printf("%d",a[i]);
    }
}