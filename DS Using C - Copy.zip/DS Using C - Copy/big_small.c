#include<stdio.h>
void main(){
    int a[5],s,l;
    printf("Enter Array Elements:");
    for(int i=0;i<=4;i++){
        scanf("%d",&a[i]);
    }
    s=l=a[0];
    for(int i=0;i<=4;i++){
        if(a[i]>l){
            l=a[i];
        }
        if(a[i]<s){
            s=a[i];
        }
    }
    printf("Smallest Element From Array: %d And Largest Element From Array: %d",s,l);
}