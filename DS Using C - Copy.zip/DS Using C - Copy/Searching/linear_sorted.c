#include<stdio.h>
void linear_sorted()
{
    int x[100], srch, i, j, k, f = 0, n;
    printf("\n How many elements you want: ");
    scanf("%d", &n);
    printf("Enter these numbers: ");

    for(i = 0; i <= n - 1; i++)
        scanf("%d", &x[i]);

    printf("\nEnter search element: ");
    scanf("%d", &srch);

    // Bubble sort logic
    for(i = 0; i <= n - 1; i++)
    {
        for(j = 0; j <= n - 2; j++)
        {
            if(x[j] > x[j + 1])
            {
                k = x[j];
                x[j] = x[j + 1];
                x[j + 1] = k;
            }
        }
    }

    printf("Sorted array: ");
    for(i = 0; i <= n - 1; i++){
        printf("\t%d", x[i]);
    }
    for(i = 0; i <= n - 1; i++)
    {
        if(srch == x[i])
        {
            f = 1;
            break;
        }
    }

    if(f == 1)
        printf("\n Element is found at position = %d", i);
    else
        printf("\n Element is not found");
}
void main(){
    linear_sorted();
}