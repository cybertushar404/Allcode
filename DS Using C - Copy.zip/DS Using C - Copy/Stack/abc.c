#include<stdio.h>
struct std{
    int roll;
    int marks;
}s;
void main(){
    struct std *p;
    p=&s;
    printf("Enter Your Roll No: ");
    scanf("%d",&p->roll);
    printf("Enter Your Marks: ");
    scanf("%d",&p->marks);
    printf("Your Roll No Is %d and Your Marks Are %d",p->roll,p->marks);
}