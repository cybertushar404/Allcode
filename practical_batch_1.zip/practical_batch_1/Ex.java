import java.util.*;
class ex{
    public static void main(String[] args){
        int i,j,k;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter First Number:");
        i = sc.nextInt();
        System.out.println("Enter Second Number:");
        j = sc.nextInt();
        try{
                k=i/j;
                System.out.println(k);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}