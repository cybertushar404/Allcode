class Vehicle:
    def __init__(self, brand, model):
        self.brand = brand
        self.model = model
        print(f"Vehicle created: {self.brand} {self.model}")

class Car(Vehicle):
    def __init__(self, brand, model, doors):
        super().__init__(brand, model)
        self.doors = doors
        print("Car created with " + str(self.doors) + " doors")

brand_input = input("Enter the brand of the car: ")
model_input = input("Enter the model of the car: ")
doors_input = int(input("Enter the number of doors: "))


my_car = Car(brand_input, model_input, doors_input)