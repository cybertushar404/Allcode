#include <stdio.h>

void main()
{
  int i, j, a[3][3], b[3][3], c[3][3];
  printf("Enter 1st matrix\n");

  for (i = 0; i <= 2; i++)
  {
    for (j = 0; j <= 2; j++)
    {
      scanf("%d", &a[i][j]);
    }
    printf("\n");
  }
  printf("Enter 2nd matrix\n");
  for (i = 0; i <= 2; i++)
  {
    for (j = 0; j <= 2; j++)
    {
      scanf("%d", &b[i][j]);
    }
    printf("\n");
  }
  printf("Substraction of two matrix is\n ");

 /* for (i = 0; i <= 2; i++)
  {
    for (j = 0; j <= 2; j++)
    {
      c[i][j] = a[i][j] - b[i][j];
    }
  }*/

  for (i = 0; i <= 2; i++)
  {
    for (j = 0; j <= 2; j++)
    {
      printf("%d", a[i][j] - b[i][j]);
    }
    printf("\n");
  }
}