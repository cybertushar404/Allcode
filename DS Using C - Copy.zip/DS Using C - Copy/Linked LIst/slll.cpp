#include <stdio.h>
#include <stdlib.h>

struct node
{
    node *next;
    int info;
} *list;

node *create();
void ins_beg(int);
void ins_bet(int, int);
void ins_end(int);
int rem_beg();
int rem_bet(int);
int rem_end();
void display();
void count();
void search(int);
void reverse();
int main()
{
    int n, af, z, ch;
    do
    {
        printf("\n1: Insert Begin\n2: Insert Between\n3:Insert End\n4: Remove Begin\n5: Remove Bet\n6: Remove End\n7: Display\n8: Count\n9: Search\n10: Reverse\n11:Exit\n");
        printf("\nEnter Your Choice: ");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            printf("Enter  The Value You Want To Insert: ");
            scanf("%d", &n);
            ins_beg(n);
            break;
        case 2:
            printf("After Which Node: ");
            scanf("%d", &af);
            printf("Enter The Value You Want To Insert: ");
            scanf("%d", &n);
            ins_bet(af, n);
            break;
        case 3:
            printf("Enter The Value You Want To Insert...");
            scanf("%d", &n);
            ins_end(n);
            break;
        case 4:
            z = rem_beg();
            printf("Removed Value Is: ", z);
            break;
        case 5:
            printf("Enter The Value You Want To Remove: ");
            scanf("%d", &n);
            z = rem_bet(n);
            break;
        case 6:
            z = rem_end();
            break;
        case 7:
            display();
            break;
        case 8:
            count();
            break;
        case 9:
            printf("Enter The Value To Search: ");
            scanf("%d", &n);
            search(n);
            break;
        case 10:
            reverse();
            break;
        case 11:
            exit(1);
            break;
        }
    } while (ch != 11);
}

struct node *create()
{
    struct node *z;
    z = (struct node *)malloc(sizeof(struct node)); // Allocate memory for 'struct node'
    return z;
}

void ins_beg(int n)
{
    node *p, *q;
    p = list;
    if (p == NULL)
    {
        p = create();
        p->info = n;
        p->next = NULL;
        p = list;
    }
    else
    {
        q = create();
        q->info = n;
        q->next = p;
        q = list;
    }
    printf("Node Is Inserted...");
}

void ins_bet(int af, int n)
{
    node *p, *q;
    p = list;
    if (p == NULL)
    {
        printf("Insert Between Not Possible As L.L Is Empty...");
    }
    else
    {
        while (p->next != NULL)
        {
            if (p->info == af)
            {
                q = create();
                q->info = n;
                q->next = NULL;
                p->next = q;
            }
            p = p->next;
        }
        printf("Node Is Inserted...");
    }
}

void ins_end(int n)
{
    node *p, *q;
    p = list;
    if (p == NULL)
    {
        p = create();
        p->info = n;
        p->next = NULL;
        p = list;
    }
    else
    {
        while (p->next != NULL)
        {
            p = p->next;
        }
        q = create();
        q->info = n;
        q->next = NULL;
        p->next = q;
    }
    printf("Node Is Inserted At The End...");
}

int rem_beg()
{
    int z;
    node *p, *q;
    p = list;
    if (p == NULL)
    {
        printf("L.L Is Empty & Remove Begin Not Possible...");
        return 0;
    }
    else
    {
        z = p->info;
        list = p->next;
        free(p);
        return z;
    }
    printf("Node Removed...");
}

int rem_bet(int af)
{
    int z;
    node *p, *temp;
    p = list;
    if (p == NULL && p->next == NULL)
    {
        printf("L.L Is Empty & Remove Between Not Possible...");
    }
    else
    {
        while (p->next != NULL)
        {
            if (p->info == af)
            {
                temp = p->next;
                z = temp->info;
                p->next = temp->next;
                free(temp);
                return z;
            }
            p = p->next;
        }
        printf("Node Is Removed...");
    }
}

int rem_end()
{
    int z;
    node *p, *temp;
    p = list;
    if (p->next == NULL)
    {
        printf("L.L Is Empty & Remove End Not Possible...");
    }
    else if (p->next == NULL)
    {
        z = p->info;
        free(p);
        list = NULL;
        return z;
    }
    else
    {
        while (p->next != NULL)
        {
            p = p->next;
        }
        temp = p->next;
        z = temp->info;
        p->next = NULL;
        free(temp);
        return z;
    }
}

void count()
{
    int cnt = 0;
    node *p;
    p = list;
        while (p != NULL)
        {
            cnt++;
            p = p->next;
        }
        printf("Total Nodes Present In L.L Are %d", cnt);
}

void display()
{
    node *p;
    p = list;
    while (p != NULL)
    {
        printf("%d ->", p->info);
        p = p->next;
    }
}

void search(int n)
{
    int a;
    node *p;
    p = list;
    while (p != NULL)
    {
        if (p->info == n)
        {
            a = 1;
            break;
        }
        p = p->next;
    }
    if (a == 1)
    {
        printf("Node Is Found...");
    }
    else
    {
        printf("Node Isn't Found....");
    }
}

void reverse()
{
    node *t1, *t2, *t3 = NULL;
    t1 = list;
    while (t1 != NULL)
    {
        t2 = t1->next;
        t1->next = t3;
        t3 = t1;
        t1 = t2;
    }
    list = t3;
    printf("\nLinked List Is Reversed...");
}