#include<stdio.h>
void binary()
{
    int x[100], srch, i, j, k, f = 0, down, up, mid, n;
    printf("\n How many elements you want: ");
    scanf("%d", &n);
    printf("Enter these numbers: ");

    for(i = 0; i <= n - 1; i++)
        scanf("%d", &x[i]);

    printf("\nEnter search element: ");
    scanf("%d", &srch);

    // Bubble sort logic
    for(i = 0; i <= n - 1; i++)
    {
        for(j = 0; j <= n - 2; j++)
        {
            if(x[j] > x[j + 1])
            {
                k = x[j];
                x[j] = x[j + 1];
                x[j + 1] = k;
            }
        }
    }

    printf("Sorted array: ");
    for(i = 0; i <= n - 1; i++){
        printf("\t%d", x[i]);
    }
    down = 0;
    up = n - 1;

    while(down <= up)  // Binary search logic
    {
        mid = (down + up) / 2;
        if(x[mid] == srch)
        {
            f = 1;
            break;
        }
        else if(srch > x[mid])
        {
            down = mid + 1;
        }
        else
        {
            up = mid - 1;
        }
    }

    if(f == 1)
        printf("\n Element is found at position = %d", mid);
    else
        printf("\n Element is not found");
}void main(){
    binary();
}