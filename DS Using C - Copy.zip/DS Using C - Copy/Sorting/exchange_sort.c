#include <stdio.h>
void exchange( )
{
    int x[100], n, i, j, k;
    printf("\n How many number you want to sort: ");
    scanf("%d", &n);
    printf("\n Enter these elements : ");

    for (i = 0; i <= n-1; i++)
        scanf("%d", &x[i]);

    for (i = 0; i <= n-1; i++)
    {
        for (j = i+1; j <= n-1; j++)
        {
            if (x[i] > x[j])
            {
                k = x[i];
                x[i] = x[j];
                x[j] = k;
            }
        }
    }

    printf("\nSorted array=");
    for (i = 0; i <= n-1; i++)
        printf("\t%d", x[i]);
}
void main(){
    exchange();
}