import java.util.*;
class vc{
    public static void main(String[] args){
        int l,v=0,c=0;
        Scanner sc = new Scanner(System.in);
      
        System.out.println("Enter String: ");
        
        
        String a=sc.nextLine();
        l=a.length();
        for(int i = 0; i<=l-1;i++){
            char ch = Character.toLowerCase(a.charAt(i));
            if(a.charAt(i)=='a' || a.charAt(i)=='e' || a.charAt(i)=='i' || a.charAt(i)=='o' || a.charAt(i)=='u'){
                v++;
            }
            else{
                c++;
            }
        }
         System.out.println("Vowels Count= "+v);
         System.out.println("Consonants Count= "+c);
    }
}