import java.util.*;

public class Collect {
    public static void main(String[] args) {
  
        Collection<String> ob = new ArrayList<>();

        ob.add("Apple");
        ob.add("Banana");
        ob.add("Mango");
        ob.add("Orange");

  
        System.out.println("Size of collection: " + ob.size());


        System.out.println("Does collection contain 'Mango'? " + ob.contains("Mango"));


        System.out.println("Is the collection empty? " + ob.isEmpty());


        ob.remove("Banana");
        System.out.println("After removing 'Banana': " + ob);

        System.out.println("Iterating using Iterator:");
        Iterator<String> iterator = ob.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

  
        ob.clear();
        System.out.println("After clear(), is the collection empty? " + ob.isEmpty());
    }
}
