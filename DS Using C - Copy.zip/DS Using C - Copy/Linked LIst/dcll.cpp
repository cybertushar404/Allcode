#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
struct node
{
    node *prev, *next;
    int info;
} *list;

struct node *create();
void ins_beg(int);
void ins_bet(int, int);
void ins_end(int);
int rem_beg();
int rem_bet(int);
int rem_end();
void display();
void count();
void search(int);
void reverse();

int main()
{
    int ch, af, x, srch;
    do
    {
        printf("\n1: Insert Begin\n2: Insert Between\n3: Insert End\n4: Remove Begin\n5: Remove Bet\n6: Remove End\n7: Display\n8: Count\n9: Search\n10: Reverse\n11:Exit\n");
        printf("\nEnter Your Choice: ");
        scanf("%d", &ch);

        switch (ch)
        {
        case 1:
            printf("Enter Value To Insert: ");
            scanf("%d", &x);
            ins_beg(x);
            printf("Node Is Inserted...");
            break;
        case 2:
            printf("After Which Node: ");
            scanf("%d", &af);
            printf("Enter Value To Insert: ");
            scanf("%d", &x);
            ins_bet(af, x);
            printf("Node Is Inserted...");
            break;
        case 3:
            printf("Enter Value To Insert: ");
            scanf("%d", &x);
            ins_end(x);
            printf("Node Is Inserted...");
            break;
        case 4:
            rem_beg();
            printf("Node Is Removed...");
            break;
        case 5:
            printf("After Which Node You Want To Remove: ");
            scanf("%d", &af);
            rem_bet(af);
            printf("Value Is Removed...");
            break;
        case 6:
            rem_end();
            printf("Node Is Removed...");
            break;
        case 7:
            display();
            break;
        case 8:
            count();
            break;
        case 9:
            printf("Enter Value To Search: ");
            scanf("%d", &srch);
            search(srch);
            break;
        /*case 10:
            reverse();
            break;*/
        case 11:
            exit(1);
            break;
        default:
            printf("Wrong Choice...");
            break;
        }
    } while (ch != 11);
}

node *create()
{
    node *z;
    z = (node *)malloc(sizeof(node));
    return z;
}

void ins_beg(int x)
{
    node *p, *q;
    p = list;
    if (p == NULL)
    {
        p = create();
        p->prev = p;
        p->info = x;
        p->next = p;
        list = p;
    }
    else
    {
        while (p->next != list)
        {
            p = p->next;
        }
        
        q = create();
        q->prev = p;
        q->info = x;
        q->next = p->next;
        p->next->prev = q;
        p->next = q;
        list = q;
    }
}

void ins_end(int x)
{
    node *p, *q;
    p = list;
    if (p == NULL)
    {
        p = create();
        p->prev = p;
        p->info = x;
        p->next = p;
        list = p;
    }
    else
    {
        while (p->next != list)
        {
            p = p->next;
        }
        q = create();
        q->prev = p;
        q->info = x;
        q->next = p->next;
        p->next->prev = q;
        p->next = q;
    }
}

void ins_bet(int af, int x)
{
    node *p, *q;
    p = list;
    if (p == NULL || (p->prev == p && p->next == p))
    {
        printf("Insert Between Not Possible...");
    }
    else
    {
        while (p->next != list)
        {
            if (p->info == af)
            {
                q = create();
                q->prev = p;
                q->info = x;
                q->next = p->next;
                p->next->prev = q;
                p->next = q;
            }
            p = p->next;
        }
    }
}

int rem_beg()
{
    int z;
    node *p, *temp;
    p = list;
    if (p == NULL)
    {
        printf("Remove Begin Not Possible As L.L Is Empty...");
    }
    else if (p->prev == p && p->next == p)
    {
        z = p->info;
        free(p);
        list = NULL;
        return z;
    }
    else
    {
        while (p->next != list)
        {
            p = p->next;
        }
        temp = p->next;
        z = temp->info;
        temp->next->prev = p;
        p->next = temp->next;
        list = temp->next;
        free(temp);
        return z;
    }
    return 0;
}

int rem_end()
{
    int z;
    node *p, *temp;
    p = list;
    if (p == NULL)
    {
        printf("Remove End Not Poossible As L.L Is Empty...");
    }
    else if (p->prev == p && p->next == p)
    {
        z = p->info;
        free(p);
        return z;
        list = NULL;
    }
    else
    {
        while (p->next->next != list)
        {
            p = p->next;
        }
        temp = p->next;
        z = temp->info;
        temp->next->prev = p;
        p->next = temp->next;
        free(temp);
        return z;
    }
    return 0;
}

int rem_bet(int af)
{
    int z;
    node *p, *temp;
    p = list;
    if (p == NULL)
    {
        printf("Remove Between Not Possible As L.L Is Empty...");
    }
    else if (p->prev == p && p->next == p)
    {
        printf("Remove Between Not Possible As L.L Is Empty...");
    }
    else
    {
        while (p->next != list)
        {
            if (p->info == af)
            {
                temp = p->next;
                z = temp->info;
                temp->next->prev = p;
                p->next = temp->next;
                free(temp);
                return z;
            }
            p = p->next;
        }
    }
    return 0;
}

void search(int srch)
{
    int a = 0;
    node *p;
    p = list;
    do
    {
        if (p->info == srch)
        {
            a = 1;
            break;
        }
        p = p->next;
    } while (p != list);

    if (a == 1)
    {
        printf("Node Is Found...");
    }
    else
    {
        printf("Node Not Found...");
    }
}

void display()
{
    node *p;
    p = list;
    do
    {
        printf("%d ", p->info);
        p = p->next;
    } while (p != list);
}

void count()
{
    int cnt = 0;
    node *p;
    p = list;
    if (p == NULL)
    {
        cnt = 0;
    }
    else
    {
        do
        {
            cnt++;
            p = p->next;
        } while (p != list);

        printf("Total Number Of Nodes: %d", cnt);
    }
}

/*void reverse()
{

}*/