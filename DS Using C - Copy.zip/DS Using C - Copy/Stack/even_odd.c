#include <stdio.h>
#define max 50
struct stack
{
    int item[max];
    int top;
};
void create(struct stack *);
void push_odd(struct stack *, int);
void push_even(struct stack *, int);
void display_odd(struct stack *p);
void display_even(struct stack *q);
void main()
{
    int x, i = 0, j = 0, k = 0;
    struct stack *p, *q, odd, even;
    p = &odd;
    q = &even;
    create(p);
    create(q);
    printf("(Enter 1 To Store & Display ODD Numbers Using Stack...) And (Enter 2 To Store & Display Even Numbers Using Stack...): ");
    scanf("%d", &x);
    if (x == 1)
    {
        printf(" From Where Do You Want To Store And Display ODD Numbers: ");
        scanf("%d", &k);
        printf(" Till Where Do You Want To Store And Display ODD Numbers: ");
        scanf("%d", &j);

        for (i = k; i <= j; i++)
        {
            if (i % 2 != 0)
            {
                push_odd(p, i);
            }
        }
        printf("ODD Numbers Are: ");
        display_odd(p);
    }
    else
    {
        printf(" From Where Do You Want To Store And Display Even Numbers: ");
        scanf("%d", &k);
        printf(" Till Where Do You Want To Store And Display Even Numbers: ");
        scanf("%d", &j);

        for (i = k; i <= j; i++)
        {
            if (i % 2 == 0)
            {
                push_even(q, i);
            }
        }
        printf("Even Numbers Are: ");
        display_even(q);
    }
}
void create(struct stack *p)
{
    p->top = -1;
}
void push_odd(struct stack *p, int i)
{
    if (p->top == max - 1)
    {
        printf("\nStack Overflow...");
    }
    else
    {
        //++p->top;
        p->item[++p->top] = i;
    }
}

void push_even(struct stack *q, int i)
{
    if (q->top == max - 1)
    {
        printf("\nStack Overflow...");
    }
    else
    {
        //++q->top;
        q->item[++q->top] = i;
    }
}

void display_odd(struct stack *p)
{
    int i;
    for (i = 0; i <= p->top; i++)
    {
        printf("%d ", p->item[i]);
    }
    printf("\n");
}

void display_even(struct stack *q)
{
    int i;
    for (i = 0; i <= q->top; i++)
    {
        printf("%d ", q->item[i]);
    }
    printf("\n");
}