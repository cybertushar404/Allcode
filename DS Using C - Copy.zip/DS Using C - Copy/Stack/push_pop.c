#include <stdio.h>

#define MAX 5

struct stack {
    int a[MAX];
    int top;
} s;

void create(struct stack *s) {
    s->top = -1;
    printf("Stack is Created\n");
}

void isempty(struct stack *s) {
    if (s->top == -1) {
        printf("Stack Is Empty\n");
    } else {
        printf("Stack Isn't Empty\n");
    }
}

void isfull(struct stack *s) {
    if (s->top == MAX - 1) {
        printf("Stack Overflow\n");
    }
}

void push(struct stack *s, int m) {
    if (s->top < MAX - 1) {
        s->a[++s->top] = m;
        printf("%d Is Pushed In Stack\n", m);
    } else {
        printf("Stack Overflow...\n");
    }
}

void pop(struct stack *s) {
    if (s->top == -1) {
        printf("Stack Underflow...\n");
    } else {
        int m = s->a[s->top--];
        printf("%d Is Popped From Stack\n", m);
    }
}

int main() {
    int m;
    create(&s);

    // Push values until the stack is full
    for (int i = 0; i < MAX; i++) {
        printf("Enter The Number You Want To Push In Stack: ");
        scanf("%d", &m);
        push(&s, m);
        printf("\n");
    }

    // Pop values until the stack is empty
    while (s.top != -1) {
        pop(&s);
    }

    return 0;
}