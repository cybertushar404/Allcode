#include <stdio.h>
#include <stdlib.h>

struct node {
    int info;
    struct node *left, *right;
};

struct node *root = NULL;

// Function to create a new node
struct node* create(int x) {
    struct node *z = (struct node*)malloc(sizeof(struct node));
    z->info = x;
    z->left = z->right = NULL;
    return z;
}

// Insert a node into BST
void insert(int x) {
    struct node *newnode = create(x), *temp;

    if (root == NULL) {
        root = newnode;
        return;
    }

    temp = root;
    while (1) {
        if (x < temp->info) {
            if (temp->left == NULL) {
                temp->left = newnode;
                break;
            }
            temp = temp->left;
        } else if (x > temp->info) {
            if (temp->right == NULL) {
                temp->right = newnode;
                break;
            }
            temp = temp->right;
        } else {
            printf("\nPlease do not repeat node...");
            free(newnode);
            break;
        }
    }
}

// Search a node
void search(int srch) {
    struct node *temp = root;
    while (temp != NULL) {
        if (srch == temp->info) {
            printf("\nNode is found");
            return;
        } else if (srch < temp->info)
            temp = temp->left;
        else
            temp = temp->right;
    }
    printf("\nNode is NOT found");
}

// Count leaf nodes
int count_leaf(struct node *p) {
    if (p == NULL) return 0;
    if (p->left == NULL && p->right == NULL) {
        printf("\t%d", p->info);
        return 1;
    }
    return count_leaf(p->left) + count_leaf(p->right);
}

// Count total nodes
int count_total(struct node *p) {
    if (p == NULL) return 0;
    return count_total(p->left) + count_total(p->right) + 1;
}

// Traversals
void preorder(struct node *p) {
    if (p != NULL) {
        printf("\t%d", p->info);
        preorder(p->left);
        preorder(p->right);
    }
}

void inorder(struct node *p) {
    if (p != NULL) {
        inorder(p->left);
        printf("\t%d", p->info);
        inorder(p->right);
    }
}

void postorder(struct node *p) {
    if (p != NULL) {
        postorder(p->left);
        postorder(p->right);
        printf("\t%d", p->info);
    }
}

// Delete operations
void del_leaf(struct node *parent, struct node *child) {
    if (child == parent->right)
        parent->right = NULL;
    else
        parent->left = NULL;
    free(child);
    printf("\nLeaf node deleted.");
}

void del_one(struct node *parent, struct node *child) {
    struct node *childLink = (child->left != NULL) ? child->left : child->right;
    if (child == parent->right)
        parent->right = childLink;
    else
        parent->left = childLink;
    free(child);
    printf("\nNode with one child deleted.");
}

void del_two(struct node *child) {
    struct node *parent = child;
    struct node *lft = child->left;

    while (lft->right != NULL) {
        parent = lft;
        lft = lft->right;
    }

    child->info = lft->info;

    if (lft->left == NULL && lft->right == NULL)
        del_leaf(parent, lft);
    else
        del_one(parent, lft);
}

// Utility to find and delete a node
void delete_node(int val) {
    struct node *temp = root, *parent = NULL;

    while (temp != NULL && temp->info != val) {
        parent = temp;
        if (val < temp->info)
            temp = temp->left;
        else
            temp = temp->right;
    }

    if (temp == NULL) {
        printf("\nNode not found.");
        return;
    }

    // Node found — check its type
    if (temp->left == NULL && temp->right == NULL)
        del_leaf(parent, temp);
    else if ((temp->left != NULL && temp->right == NULL) || (temp->left == NULL && temp->right != NULL))
        del_one(parent, temp);
    else
        del_two(temp);
}

int main() {
    int choice, val;

    while (1) {
        printf("\n\n--- BST OPERATIONS ---");
        printf("\n1. Insert");
        printf("\n2. Search");
        printf("\n3. Preorder Traversal");
        printf("\n4. Inorder Traversal");
        printf("\n5. Postorder Traversal");
        printf("\n6. Count Leaf Nodes");
        printf("\n7. Count Total Nodes");
        printf("\n8. Delete Node");
        printf("\n9. Exit");
        printf("\nEnter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to insert: ");
                scanf("%d", &val);
                insert(val);
                break;
            case 2:
                printf("Enter value to search: ");
                scanf("%d", &val);
                search(val);
                break;
            case 3:
                printf("Preorder Traversal:\n");
                preorder(root);
                break;
            case 4:
                printf("Inorder Traversal:\n");
                inorder(root);
                break;
            case 5:
                printf("Postorder Traversal:\n");
                postorder(root);
                break;
            case 6:
                printf("Leaf nodes are: ");
                printf("\nTotal leaf nodes = %d", count_leaf(root));
                break;
            case 7:
                printf("Total nodes = %d", count_total(root));
                break;
            case 8:
                printf("Enter value to delete: ");
                scanf("%d", &val);
                delete_node(val);
                break;
            case 9:
                exit(0);
            default:
                printf("Invalid choice!");
        }
    }
    return 0;
}
