/*

***STACK***

Definition: “Stack is the linear data structure which is an ordered collection of elements or 
items into which elements or items are inserted (push) and removed (pop) from only one end
that end is called top of Stack.”
The Stack operates in LIFO (Last In First Out) manner i.e. the element which is lastly 
inserted in stack is the element to come out first from stack. Because stack has only one end 
to insert and remove element.
e.g.- 1) Stack of CD plates-
In Stack of CD plate only topmost CD can be taken out and any new CD can be put at the 
top.
2) Stack of boxes.
*/
#include <stdio.h>
#include <process.h>
#define max 5
struct stack
{
   int item[max], top;
} s;
void create(struct stack *);
void isempty(struct stack *);
void isfull(struct stack *);
void push(struct stack *, int);
int pop(struct stack *);
void display(struct stack *);
void main()
{
   int ch, x, z;
   struct stack *p = &s; // Init. of ptr
   do
   {
      printf("\nEnter  your choice ");
      printf("\n1:Create\n2:Isempty\n3:Isfull\n4:Push\n5:POP\n6:Display\n7:Exit\n");
      scanf("%d", &ch);
      switch (ch)
      {
      case 1:
         create(p); // call
         break;
      case 2:
         isempty(p); // call
         break;
      case 3:
         isfull(p); // call
         break;
      case 4:
         printf("\nEnter val to push= ");
         scanf("%d", &x);
         push(p, x); // call
         break;
      case 5:
         z = pop(p); // call
         printf("\nPopped val=%d", z);
         break;
      case 6:
         display(p); // call
         break;
      case 7:
         exit(1);
      }
   } while (ch != 7);
}
void create(struct stack *p)
{
   p->top = -1;
   printf("\nStack is created..");
}
void isempty(struct stack *p)
{
   if (p->top == -1)
   {
      printf("\nStack is EMPTY");
   }
   else
   {
      printf("\nStack is NOT Empty");
   }
}
void isfull(struct stack *p)
{
   if (p->top == max - 1)
   {
      printf("\nStack is FULL");
   }
   else
   {
      printf("\nStack is NOT FULL");
   }
}
void push(struct stack *p, int x)
{
   if (p->top == max - 1)
   {
      printf("\nStack Overflow..");
   }
   else
   {
      ++p->top;
      p->item[p->top] = x;
      printf("\nElement Is Pushed..");
   }
}
int pop(struct stack *p)
{
   if (p->top == -1)
   {
      printf("\nStack Underflow");
      return (0);
   }
   else
   {
      return (p->item[p->top--]);
   }
}
void display(struct stack *p)
{
   int i;
   for (i = p->top; i >= 0; i--)
   {
      printf("\n%d", p->item[i]);
   }
}