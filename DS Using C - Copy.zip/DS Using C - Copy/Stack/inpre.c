/*
To convert Infix Expression into Prefix Expression we require following things:
1) Infix expression string which is parenthesized.
2) One Stack say ‘Opstack’ to store closing parenthesis and operator.
3) One Stack say ‘Oprndstack’ to store operands.
4) Prefix expression string to store result.

Algorithm:
Step 1: Start
Step 2: Input infix expression string which is parenthesized.
Step 3: Reverse the infix expression String.
Step 4: Read character by character of the reverse infix expression string.
Step 5: * If Reading character is closing parenthesis or operator then push that 
        character into Opstack.
        * If Reading character is Operand then push it into Oprnd stack.
        * If Reading character is opening parenthesis then repeatedly pop the 
        Opstack and push the popped character into Oprndstack if it is not 
        parenthesis, until the Opstack becomes empty.
Step 6: Repeat the Step 4 and Step 5 till to the end of reverse infix expression string.
Step 7: After reading entire reverse infix string,
 Check Opstack is empty or not. If Opstack is Not empty then perform pop 
 operation repeatedly until Opstack becomes empty and push popped 
 character into Oprndstack if it not parenthesis.
Step 8: Lastly, perform pop operation repeatedly onto Oprndstack until it becomes 
 empty and add the popped character into prefix expression string if it is not 
 parenthesis.
Step 9: Display prefix expression string. 
Step 10: Stop.
e.g. - 1) Infix expression: ( X + ( Y * Z ) )
-> Reverse Infix expression string: ) ) Z * Y ( + X (
*/
#include <stdio.h>
#include <string.h>
#define max 50

struct stack
{
    int item[max];
    int top;
};

void create(struct stack *);
void push(struct stack *p, int);
char pop(struct stack *p);

int main()
{
    char ch, in[50], pre[50];
    int i = 0, j = 0;
    struct stack *ops, *oprnd, a, b;
    ops = &a;
    oprnd = &b;
    create(ops);
    create(oprnd);
    printf("\n Enter Infix Exp: ");
    scanf("%s", &in);
    strrev(in);
    while (in[i] != '\0')
    {
        if (in[i] == ')' || in[i] == '+' || in[i] == '-' || in[i] == '*' || in[i] == '/' || in[i] == '^' || in[i] == '$')
        {
            push(ops, in[i]);
        }
        else if (in[i] == '(')
        {
            while (ops->top != -1)
            {
                ch = pop(ops);
                if (ch != ')')
                {
                    push(oprnd, ch);
                }
            }
        }
        else
        {
            push(oprnd, in[i]);
        }
        i++;
    }
    if (ops->top != -1)
    {
        while (ops->top != -1)
        {
            ch = pop(ops);
            if (ch != ')')
            {
                push(oprnd, ch);
            }
        }
    }
    while (oprnd->top != -1)
    {
        pre[j] = pop(oprnd);
        j++;
    }
    pre[j] = '\0';

    printf("\n Postfix Exp: %s", pre);
    return 0;
}

void create(struct stack *p)
{
    p->top = -1;
}

void push(struct stack *p, int x)
{
    if (p->top == max - 1)
    {
        printf("Stack Overflow...\n");
    }
    else
    {
        p->top++;
        p->item[p->top] = x;
    }
}

char pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Underflow...\n");
        return 0;
    }
    else
    {
        return p->item[p->top--];
    }
}