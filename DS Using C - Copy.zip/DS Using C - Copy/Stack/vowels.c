#include <stdio.h>
#define max 50
struct stack
{
    int item[max];
    int top;
} s;
void create(struct stack *p);
void push(struct stack *p, int);
int pop(struct stack *p);
void main()
{
    int x, i = 0, j = 0;
    struct stack *p;
    p = &s;
    char in[50];
    printf("Enter A String: ");
    scanf("%s", &in);
    while (in[i] != '\0')
    {
        if (in[i] == 'a' || in[i] == 'A' || in[i] == 'e' || in[i] == 'E' || in[i] == 'i' || in[i] == 'I' || in[i] == 'o' || in[i] == 'O' || in[i] == 'u' || in[i] == 'U')
        {
            push(p, in[i]);
            j++;
        }
        i++;
    }
    printf("The Number Of Vowels Present In The Entered String Is: %d", j);
}
void create(struct stack *p)
{
    p->top = -1;
}
void push(struct stack *p, int x)
{
    if (p->top == max - 1)
    {
        printf("\nStack Overflow...");
    }
    else
    {
        ++p->top;
        p->item[p->top] = x;
    }
}
int pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Underflow");
        return 0;
    }
    else
    {
        return (p->item[p->top--]);
    }
}