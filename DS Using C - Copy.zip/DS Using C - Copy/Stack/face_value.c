#include <stdio.h>
#define max 50
struct stack
{
    int item[max];
    int top;
} s;
void create(struct stack *);
void push(struct stack *, int x);
int pop(struct stack *);
int main()
{
    struct stack *p = &s;
    int sum, n, rem;
    create(p);
    printf("Enter  A Number: ");
    scanf("%d", &n);

    while (n >= 10)
    {
        sum=0;
        int temp=n%10;
        push(p, temp);
        n = n / 10;
    }
    while (p->top != -1 || n >= 10)
    {
        sum = 0;
        while(n>0)
        {
            int temp=n%10;
            push(p,temp);
            n=n/10;
        }
        while(p->top!=-1)
        {
            sum=sum+pop(p);
        }
        n=sum;
    }
    printf("Face Value Is %d", n);
}
void create(struct stack *p)
{
    p->top = -1;
}
void push(struct stack *p, int x)
{
    if (p->top == max - 1)
    {
        printf("Stack Overflow...");
    }
    else
    {
        p->item[++p->top] = x;
    }
}
int pop(struct stack *p)
{
    if (p->top == -1)
    {
        printf("Stack Underflow...");
        return 0;
    }
    else
    {
        return p->item[p->top--];
    }
}